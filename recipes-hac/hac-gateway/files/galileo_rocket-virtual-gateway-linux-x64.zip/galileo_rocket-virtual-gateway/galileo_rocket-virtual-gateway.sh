#!/bin/bash

#
# Copyright (c) 2015 Wind River Systems, Inc.
#
# The right to copy, distribute, modify or otherwise make use
# of this software may be licensed only pursuant to the terms
# of an applicable Wind River license agreement.
#
#

VIRTUALGATEWAY_DIR=$(cd `dirname $0` && pwd)
VIRTUALGATEWAY_BIN_DIR=$VIRTUALGATEWAY_DIR/virtual-gateway/bin
VIRTUALGATEWAY_EXE=$VIRTUALGATEWAY_BIN_DIR/appvirtgw

deviceName="galileo_rocket"
serverURL="https://app.cloud.windriver.com/"
deviceId="galileo_rocket_8b26cf3c-11b7-4911-892c-9f4374a71d3b"
deviceManagerWS="WSS:52.24.248.3:443;GetUrl=/devmgr/v1//galileo_rocket_8b26cf3c-11b7-4911-892c-9f4374a71d3b;ID=galileo_rocket_Gateway_5d82e43a-6f10-4e0d-a966-e3b15d893e6a"
serialParams="115200-8-N-1-N"
version=0.2

echo ""
echo "Helix App Cloud Virtual Gateway for device $deviceName on server $serverURL"
echo  "Version: $version"
echo ""

serial_baudrate_default=115200
serial_port_default=
serial_default_file=$VIRTUALGATEWAY_DIR/serial_port.txt
proxy_default_file=$VIRTUALGATEWAY_DIR/proxy.txt

serial_port=""
serial_baudrate=""

if [ -f "$serial_default_file" ]; then
    serial_port_default=`cat $serial_default_file | awk '{print $1}'`
    serial_baudrate_default=`cat $serial_default_file | awk '{print $2}'`
fi

echo "Provide the name of the serial port your device is connected to:"

while (true); do
    if [ "$serial_port_default" != "" ]; then
        echo -n "Serial port (default is $serial_port_default): "
    else
        echo -n "Serial port: "
    fi
    read serial_port
    if [ "$serial_port" = "" ]; then
        serial_port=$serial_port_default
    fi
    if [ ! -c "$serial_port" ]; then
        echo "ERROR: \"$serial_port\" is not a character device file."
    elif [ ! -r $serial_port ]; then
        echo "ERROR: \"$serial_port\" is not accessible by the user."
    elif [ ! -w $serial_port ]; then
        echo "ERROR: \"$serial_port\" is not writable by the user."
    else
        break
    fi
done

if [ "$serialParams" = "" ]; then
    while [ "$serial_baudrate" = "" ]; do
        echo -n "Serial port baudrate (default is $serial_baudrate_default): "
        read serial_baudrate

        if [ "$serial_baudrate" = "" ]; then
            serial_baudrate=$serial_baudrate_default
        fi

        case $serial_baudrate in
            110|300|600|1200|2400|4800|9600|14400|19200|28800|38400|56000|57600|115200|230400|460800|921600)
                ;;
            *)
                echo "Error: unsupported serial baudrate."
                serial_baudrate=""
                ;;
        esac
    done
    serialParams=$serial_baudrate
else
    echo "Connecting serial port with serial parameters (from the SDK): $serialParams"
fi

# Store serial name and baudrate localy

echo "$serial_port $serial_baudrate" > $serial_default_file
echo ""

enable_proxy=false
while (true); do
    if [ -f "$proxy_default_file" ]; then
        default="y"
    else
        default="n"
    fi
    echo -n "Configure a SOCKS v5 proxy to access App Cloud server (y/n, default is $default): "
    read key
    if [ "$key" = "" ]; then
        key=$default
    fi
    if [ "$key" = "n" -o "$key" = "N" ]; then
        enable_proxy=false
        break
    elif [ "$key" = "y" -o "$key" = "Y" ]; then
        enable_proxy=true
        break
    fi
done
if ($enable_proxy); then
    if [ -f "$proxy_default_file" ]; then
        host_proxy_default=`cat $proxy_default_file | awk '{print $1}'`
        port_proxy_default=`cat $proxy_default_file | awk '{print $2}'`
    fi
    while [ "$host_proxy" = "" ]; do
        if [ "$host_proxy_default" != "" ]; then
            echo -n "SOCKS v5 proxy host (default is $host_proxy_default): "
        else
            echo -n "SOCKS v5 proxy host: "
        fi
        read host_proxy
        if [ "$host_proxy" = "" -a "$host_proxy_default" != "" ]; then
            host_proxy=$host_proxy_default
        fi
    done
    while [ "$port_proxy" = "" ]; do
        if [ "$port_proxy_default" != "" ]; then
            echo -n "SOCKS v5 proxy port (default is $port_proxy_default): "
        else
            echo -n "SOCKS v5 proxy port: "
        fi
        read port_proxy
        if [ "$port_proxy" = "" -a "$port_proxy_default" != "" ]; then
            port_proxy=$port_proxy_default
        fi
    done
    echo "$host_proxy $port_proxy" > $proxy_default_file
else
    /bin/rm -f $proxy_default_file
fi

if [ "$host_proxy" != "" -a "$port_proxy" != "" ]; then
    proxy_arg="-p $host_proxy:$port_proxy"
else
    proxy_arg=""
fi


# Start the gateway

echo ""
echo "Starting the Virtual Gateway for $deviceName."
LD_LIBRARY_PATH=$VIRTUALGATEWAY_BIN_DIR:$LD_LIBRARY_PATH exec "$VIRTUALGATEWAY_EXE" $proxy_arg -device "serial:$serial_port,Params=$serialParams,ID=$deviceId" "$deviceManagerWS"
