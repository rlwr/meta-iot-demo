#!/bin/bash
SCRIPT_DIR=`dirname $0`
LD_LIBRARY_PATH=$SCRIPT_DIR/bin:$LD_LIBRARY_PATH $SCRIPT_DIR/bin/appvirtgw $@
